package com.example.video_trimmer_package

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
